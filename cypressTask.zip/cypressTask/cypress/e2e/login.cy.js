describe ('Login Test',function(){

  it('Visit the login page', function(){
          cy.visit("https://www.amazon.in/?&ext_vrnc=hi&tag=googhydrabk1-21&ref=pd_sl_7hz2t19t5c_e&adgrpid=58355126069&hvpone=&hvptwo=&hvadid=610644601173&hvpos=&hvnetw=g&hvrand=12516106526432198134&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9062141&hvtargid=kwd-10573980&hydadcr=14453_2316415")
          cy.get('#nav-signin-tooltip > .nav-action-button > .nav-action-inner').click()
          cy.get('#ap_email').type('mobno')
          cy.get('.a-button-inner > #continue').click()
          cy.get('#ap_password').type('password')
          cy.get('#signInSubmit').click()
          cy.get('#twotabsearchtextbox').type('boat airdopes')
        cy.get('#nav-search-submit-button').click()
        cy.visit('https://www.amazon.in/Noise-Wireless-40-Hours-Playtime-Instacharge/dp/B0B9793WZD/ref=sr_1_1_sspa?crid=108CC7170EJY9&keywords=boat+airdopes&qid=1677562319&sprefix=boat+airdope%2Caps%2C282&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1')
        cy.get('#add-to-cart-button').click()
        //cy.get('.nav-cart-icon nav-sprite').click()
        cy.get('#nav-cart-count-container').click()
        cy.get('#sc-buy-box-ptc-button > .a-button-inner > .a-button-input').click()
        cy.get('[data-testid="Address_selectShipToThisAddress"]').click()
        cy.get('#pp-BVHVJM-136').click()
        cy.get('#bottomSubmitOrderButtonId > .a-button-inner > [data-testid]').click()
        cy.get('.a-link-emphasis > .break-word').click()
        cy.get('#Cancel-items_4').click()
        cy.get(':nth-child(2) > [nowrap="nowrap"] > input').click()
        cy.get(':nth-child(5) > [nowrap="nowrap"] > input').click()
        cy.get(':nth-child(8) > [nowrap="nowrap"] > input').click()
        cy.get('.a-button-input').click()


      })

  

 
})